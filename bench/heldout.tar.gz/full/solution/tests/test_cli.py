import pytest

from tinytodo.cli import main


@pytest.fixture
def run(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("TINYTODO_FILE", raising=False)
    path = tmp_path / "todo.json"

    def _run(*args):
        code = main(["--file", str(path), *args])
        out, err = capsys.readouterr()
        return code, out, err

    return _run


def test_add_then_list(run):
    assert run("add", "Buy milk") == (0, "Added task 1: Buy milk\n", "")
    run("add", "Pay rent", "--priority", "high")
    run("add", "Water plants", "--priority", "low")
    code, out, _ = run("list")
    assert code == 0
    assert out == "[ ] 1 Buy milk\n[ ] 2 Pay rent (high)\n[ ] 3 Water plants (low)\n"


def test_done_hides_task_unless_all(run):
    run("add", "Buy milk")
    run("add", "Pay rent")
    assert run("done", "1") == (0, "Completed task 1: Buy milk\n", "")
    assert run("list")[1] == "[ ] 2 Pay rent\n"
    assert run("list", "--all")[1] == "[x] 1 Buy milk\n[ ] 2 Pay rent\n"


def test_remove(run):
    run("add", "Buy milk")
    assert run("remove", "1") == (0, "Removed task 1: Buy milk\n", "")
    assert run("list", "--all")[1] == ""


def test_tags(run):
    run("add", "Buy milk", "--priority", "low", "--tag", "home", "--tag", "errands")
    run("add", "Pay rent", "--tag", "bills")
    assert run("list")[1] == "[ ] 1 Buy milk (low) #home #errands\n[ ] 2 Pay rent #bills\n"
    assert run("tag", "2", "home", "home") == (0, "Tagged task 2: Pay rent\n", "")
    assert run("untag", "1", "errands", "nope") == (0, "Untagged task 1: Buy milk\n", "")
    assert run("list", "--tag", "home")[1] == "[ ] 1 Buy milk (low) #home\n[ ] 2 Pay rent #bills #home\n"
    assert run("add", "Bad", "--tag", "no_good") == (1, "", "error: invalid tag: no_good\n")


def test_edit(run):
    run("add", "Buy milk")
    assert run("edit", "1", "--title", "Buy bread", "--priority", "high") == (
        0,
        "Edited task 1: Buy bread\n",
        "",
    )
    assert run("list")[1] == "[ ] 1 Buy bread (high)\n"
    assert run("edit", "1") == (1, "", "error: nothing to edit\n")


def test_sort_priority(run):
    run("add", "A", "--priority", "low")
    run("add", "B")
    run("add", "C", "--priority", "high")
    assert run("list", "--sort", "priority")[1] == "[ ] 3 C (high)\n[ ] 2 B\n[ ] 1 A (low)\n"


def test_search(run):
    run("add", "Buy milk")
    run("add", "Pay rent")
    assert run("search", "MILK") == (0, "[ ] 1 Buy milk\n", "")
    assert run("search", "bread") == (0, "No matches.\n", "")


def test_stats(run):
    run("add", "A", "--priority", "high")
    run("add", "B", "--priority", "high")
    run("add", "C")
    run("done", "2")
    assert run("stats")[1] == "Total: 3\nDone: 1\nPending: 2\nHigh priority pending: 1\n"


def test_export(run):
    run("add", "Milk, eggs", "--tag", "home", "--tag", "shop")
    run("add", "Pay rent", "--priority", "high", "--tag", "bills")
    run("done", "2")
    assert run("export", "--format", "csv")[1] == (
        'id,title,priority,done,tags\n1,"Milk, eggs",normal,no,home;shop\n2,Pay rent,high,yes,bills\n'
    )
    assert run("export", "--format", "markdown")[1] == (
        "# Tasks\n\n- [ ] Milk, eggs #home #shop\n- [x] Pay rent (high) #bills\n"
    )
    with pytest.raises(SystemExit) as exc:
        run("export", "--format", "json")
    assert exc.value.code == 2


def test_unknown_id_is_an_error(run):
    assert run("done", "7") == (1, "", "error: no task with id 7\n")
    assert run("remove", "7") == (1, "", "error: no task with id 7\n")


def test_empty_title_is_an_error(run):
    assert run("add", "   ") == (1, "", "error: title must not be empty\n")


def test_bad_priority_is_a_usage_error(run):
    with pytest.raises(SystemExit) as exc:
        run("add", "Buy milk", "--priority", "urgent")
    assert exc.value.code == 2


def test_env_var_picks_the_file(tmp_path, capsys, monkeypatch):
    path = tmp_path / "other.json"
    monkeypatch.setenv("TINYTODO_FILE", str(path))
    assert main(["add", "Buy milk"]) == 0
    assert path.exists()


def test_default_file_is_in_the_current_directory(tmp_path, capsys, monkeypatch):
    monkeypatch.delenv("TINYTODO_FILE", raising=False)
    monkeypatch.chdir(tmp_path)
    assert main(["add", "Buy milk"]) == 0
    assert (tmp_path / "todo.json").exists()
