"""The task record and its validation."""

from __future__ import annotations

import re
from collections.abc import Iterable
from dataclasses import asdict, dataclass, field
from typing import Any

PRIORITIES = ("low", "normal", "high")
_TAG = re.compile(r"[a-z0-9][a-z0-9-]*")


@dataclass
class Task:
    """One to-do item. The title is stripped; an empty title is an error.

    `tags` are lowercase, in the order added, without duplicates.
    """

    id: int
    title: str
    priority: str = "normal"
    done: bool = False
    tags: list[str] = field(default_factory=list)

    def __post_init__(self) -> None:
        self.title = validate_title(self.title)
        self.priority = validate_priority(self.priority)
        self.tags = merge_tags([], self.tags)

    def to_dict(self) -> dict[str, Any]:
        """Return the task as a JSON-ready dict."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Task:
        """Build a task from a dict read from the task file."""
        return cls(
            id=int(data["id"]),
            title=data["title"],
            priority=data.get("priority", "normal"),
            done=bool(data.get("done", False)),
            tags=list(data.get("tags", [])),
        )


def validate_title(title: str) -> str:
    """Return the stripped title, or raise ValueError if nothing is left."""
    cleaned = title.strip()
    if not cleaned:
        raise ValueError("title must not be empty")
    return cleaned


def validate_priority(priority: str) -> str:
    """Return the priority if it is known, else raise ValueError."""
    if priority not in PRIORITIES:
        raise ValueError(f"unknown priority: {priority}")
    return priority


def validate_tag(tag: str) -> str:
    """Return the lowercased tag, or raise ValueError showing the tag as given."""
    cleaned = tag.lower() if isinstance(tag, str) else tag
    if not isinstance(cleaned, str) or not _TAG.fullmatch(cleaned) or not cleaned.isascii():
        raise ValueError(f"invalid tag: {tag}")
    return cleaned


def merge_tags(current: Iterable[str], new: Iterable[str]) -> list[str]:
    """Return `current` followed by the valid `new` tags it does not have yet."""
    merged = list(current)
    for tag in new:
        cleaned = validate_tag(tag)
        if cleaned not in merged:
            merged.append(cleaned)
    return merged
