"""The tinytodo command line."""

from __future__ import annotations

import argparse
import csv
import io
import os
import sys
from collections.abc import Sequence

from tinytodo.model import PRIORITIES, Task
from tinytodo.store import TaskNotFound, TaskStore

DEFAULT_FILE = "todo.json"
PRIORITY_ORDER = {"high": 0, "normal": 1, "low": 2}


def suffix(task: Task) -> str:
    """Return the priority and tag suffix that follows a task's title."""
    text = f" ({task.priority})" if task.priority != "normal" else ""
    return text + "".join(f" #{tag}" for tag in task.tags)


def format_task(task: Task) -> str:
    """Return the one-line form of a task, as `list` prints it."""
    mark = "x" if task.done else " "
    return f"[{mark}] {task.id} {task.title}{suffix(task)}"


def build_parser() -> argparse.ArgumentParser:
    """Return the argument parser for all commands."""
    parser = argparse.ArgumentParser(prog="tinytodo", description="A small to-do list.")
    parser.add_argument(
        "--file",
        default=None,
        help=f"task file (default: $TINYTODO_FILE or {DEFAULT_FILE})",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    add = sub.add_parser("add", help="add a task")
    add.add_argument("title")
    add.add_argument("--priority", choices=PRIORITIES, default="normal")
    add.add_argument("--tag", action="append", default=[], help="add a tag (can repeat)")

    lst = sub.add_parser("list", help="list tasks")
    lst.add_argument("--all", action="store_true", help="include done tasks")
    lst.add_argument("--tag", default=None, help="only tasks with this tag")
    lst.add_argument("--sort", choices=("id", "priority"), default="id")

    done = sub.add_parser("done", help="mark a task done")
    done.add_argument("id", type=int)

    remove = sub.add_parser("remove", help="delete a task")
    remove.add_argument("id", type=int)

    tag = sub.add_parser("tag", help="add tags to a task")
    tag.add_argument("id", type=int)
    tag.add_argument("tags", nargs="+")

    untag = sub.add_parser("untag", help="remove tags from a task")
    untag.add_argument("id", type=int)
    untag.add_argument("tags", nargs="+")

    edit = sub.add_parser("edit", help="change a task's title or priority")
    edit.add_argument("id", type=int)
    edit.add_argument("--title", default=None)
    edit.add_argument("--priority", choices=PRIORITIES, default=None)

    search = sub.add_parser("search", help="find tasks by title")
    search.add_argument("text")

    sub.add_parser("stats", help="count tasks")

    export = sub.add_parser("export", help="print all tasks as CSV or Markdown")
    export.add_argument("--format", choices=("csv", "markdown"), required=True)
    return parser


def task_file(arg: str | None) -> str:
    """Pick the task file: --file, then $TINYTODO_FILE, then the default."""
    return arg or os.environ.get("TINYTODO_FILE") or DEFAULT_FILE


def cmd_add(store: TaskStore, args: argparse.Namespace) -> int:
    task = store.add(args.title, priority=args.priority, tags=args.tag)
    store.save()
    print(f"Added task {task.id}: {task.title}")
    return 0


def cmd_list(store: TaskStore, args: argparse.Namespace) -> int:
    tasks = store.list(include_done=args.all)
    if args.tag is not None:
        tasks = [t for t in tasks if args.tag in t.tags]
    if args.sort == "priority":
        tasks = sorted(tasks, key=lambda t: (PRIORITY_ORDER[t.priority], t.id))
    for task in tasks:
        print(format_task(task))
    return 0


def cmd_done(store: TaskStore, args: argparse.Namespace) -> int:
    task = store.complete(args.id)
    store.save()
    print(f"Completed task {task.id}: {task.title}")
    return 0


def cmd_remove(store: TaskStore, args: argparse.Namespace) -> int:
    task = store.remove(args.id)
    store.save()
    print(f"Removed task {task.id}: {task.title}")
    return 0


def cmd_tag(store: TaskStore, args: argparse.Namespace) -> int:
    task = store.tag(args.id, args.tags)
    store.save()
    print(f"Tagged task {task.id}: {task.title}")
    return 0


def cmd_untag(store: TaskStore, args: argparse.Namespace) -> int:
    task = store.untag(args.id, args.tags)
    store.save()
    print(f"Untagged task {task.id}: {task.title}")
    return 0


def cmd_edit(store: TaskStore, args: argparse.Namespace) -> int:
    if args.title is None and args.priority is None:
        raise ValueError("nothing to edit")
    task = store.edit(args.id, title=args.title, priority=args.priority)
    store.save()
    print(f"Edited task {task.id}: {task.title}")
    return 0


def cmd_search(store: TaskStore, args: argparse.Namespace) -> int:
    matches = store.search(args.text)
    if not matches:
        print("No matches.")
    for task in matches:
        print(format_task(task))
    return 0


def cmd_stats(store: TaskStore, args: argparse.Namespace) -> int:
    tasks = store.list(include_done=True)
    pending = [t for t in tasks if not t.done]
    print(f"Total: {len(tasks)}")
    print(f"Done: {len(tasks) - len(pending)}")
    print(f"Pending: {len(pending)}")
    print(f"High priority pending: {sum(t.priority == 'high' for t in pending)}")
    return 0


def cmd_export(store: TaskStore, args: argparse.Namespace) -> int:
    tasks = store.list(include_done=True)
    if args.format == "csv":
        buf = io.StringIO()
        writer = csv.writer(buf, lineterminator="\n")
        writer.writerow(["id", "title", "priority", "done", "tags"])
        for t in tasks:
            writer.writerow([t.id, t.title, t.priority, "yes" if t.done else "no", ";".join(t.tags)])
        sys.stdout.write(buf.getvalue())
    else:
        print("# Tasks")
        print()
        for t in tasks:
            mark = "x" if t.done else " "
            print(f"- [{mark}] {t.title}{suffix(t)}")
    return 0


COMMANDS = {
    "add": cmd_add,
    "list": cmd_list,
    "done": cmd_done,
    "remove": cmd_remove,
    "tag": cmd_tag,
    "untag": cmd_untag,
    "edit": cmd_edit,
    "search": cmd_search,
    "stats": cmd_stats,
    "export": cmd_export,
}


def main(argv: Sequence[str] | None = None) -> int:
    """Run one command and return the exit status."""
    args = build_parser().parse_args(argv)
    try:
        store = TaskStore(task_file(args.file))
        return COMMANDS[args.command](store, args)
    except (TaskNotFound, ValueError) as exc:
        message = exc.args[0] if exc.args else str(exc)
        print(f"error: {message}", file=sys.stderr)
        return 1
