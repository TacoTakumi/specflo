"""Held-out checks for the full request: tags, edit, sort, search, stats and export."""

import csv
import io
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

import tinytodo
from tinytodo.cli import main
from tinytodo.model import Task
from tinytodo.store import TaskNotFound, TaskStore


@pytest.fixture
def todo(tmp_path, monkeypatch):
    monkeypatch.delenv("TINYTODO_FILE", raising=False)
    return tmp_path / "todo.json"


@pytest.fixture
def run(todo, capsys):
    def _run(*args):
        code = main(["--file", str(todo), *args])
        out, err = capsys.readouterr()
        return code, out, err

    return _run


def _module(todo, *args):
    """Run `python -m tinytodo` in a fresh process, so usage errors show their real exit status."""
    env = {k: v for k, v in os.environ.items() if k != "TINYTODO_FILE"}
    env["PYTHONPATH"] = str(Path(tinytodo.__file__).resolve().parent.parent)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        [sys.executable, "-m", "tinytodo", "--file", str(todo), *args],
        cwd=todo.parent,
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )


# Tags: model and store


def test_tags_default_to_an_empty_list():
    assert Task(id=1, title="Buy milk").tags == []


def test_store_add_takes_tags(todo):
    store = TaskStore(todo)
    task = store.add("Buy milk", priority="low", tags=("home", "errands"))
    assert (task.priority, task.tags) == ("low", ["home", "errands"])
    assert store.add("Pay rent").tags == []


@pytest.mark.parametrize("tag", ["home", "a", "9lives", "to-do", "x-1-y"])
def test_valid_tags_are_kept(todo, tag):
    assert TaskStore(todo).add("Buy milk", tags=[tag]).tags == [tag]


def test_uppercase_tags_are_lowercased(todo):
    assert TaskStore(todo).add("Buy milk", tags=["HOME", "Big-Shop"]).tags == ["home", "big-shop"]


@pytest.mark.parametrize("tag", ["-home", "home_work", "home!", "two words", ""])
def test_invalid_tags_are_rejected(todo, tag):
    store = TaskStore(todo)
    with pytest.raises(ValueError) as exc:
        store.add("Buy milk", tags=[tag])
    assert str(exc.value) == f"invalid tag: {tag}"


def test_invalid_tag_message_shows_the_tag_as_given(todo):
    with pytest.raises(ValueError) as exc:
        TaskStore(todo).add("Buy milk", tags=["-Home"])
    assert str(exc.value) == "invalid tag: -Home"


def test_tags_keep_order_without_duplicates(todo):
    task = TaskStore(todo).add("Buy milk", tags=["home", "errands", "home", "HOME", "a"])
    assert task.tags == ["home", "errands", "a"]


def test_tags_are_saved_and_reloaded(todo):
    store = TaskStore(todo)
    store.add("Buy milk", tags=["home", "errands"])
    store.save()
    data = json.loads(todo.read_text(encoding="utf-8"))
    assert data["tasks"][0]["tags"] == ["home", "errands"]
    assert TaskStore(todo).get(1).tags == ["home", "errands"]


def test_old_file_without_tags_still_loads(todo, run):
    todo.write_text(
        json.dumps(
            {
                "version": 1,
                "next_id": 3,
                "tasks": [
                    {"id": 1, "title": "Buy milk", "priority": "low", "done": False},
                    {"id": 2, "title": "Pay rent", "priority": "normal", "done": True},
                ],
            }
        ),
        encoding="utf-8",
    )
    assert [t.tags for t in TaskStore(todo).list(include_done=True)] == [[], []]
    assert run("list", "--all") == (0, "[ ] 1 Buy milk (low)\n[x] 2 Pay rent\n", "")


# Tags: command line


def test_add_with_tags_then_list(run):
    assert run("add", "Pay rent") == (0, "Added task 1: Pay rent\n", "")
    assert run("add", "Buy milk", "--priority", "low", "--tag", "home", "--tag", "errands")[0] == 0
    assert run("add", "Call mom", "--tag", "Family")[0] == 0
    assert run("list") == (
        0,
        "[ ] 1 Pay rent\n[ ] 2 Buy milk (low) #home #errands\n[ ] 3 Call mom #family\n",
        "",
    )


def test_add_with_invalid_tag_is_an_error(run):
    assert run("add", "Buy milk", "--tag", "bad tag") == (1, "", "error: invalid tag: bad tag\n")
    assert run("list", "--all") == (0, "", "")


def test_tag_command(run):
    run("add", "Buy milk", "--tag", "home")
    assert run("tag", "1", "errands", "home", "Shop") == (0, "Tagged task 1: Buy milk\n", "")
    assert run("list") == (0, "[ ] 1 Buy milk #home #errands #shop\n", "")


def test_tag_command_with_an_existing_tag_is_not_an_error(run):
    run("add", "Buy milk", "--tag", "home")
    assert run("tag", "1", "home") == (0, "Tagged task 1: Buy milk\n", "")
    assert run("list") == (0, "[ ] 1 Buy milk #home\n", "")


def test_tag_command_errors(run):
    run("add", "Buy milk")
    assert run("tag", "9", "home") == (1, "", "error: no task with id 9\n")
    assert run("tag", "1", "bad_tag") == (1, "", "error: invalid tag: bad_tag\n")
    assert run("list") == (0, "[ ] 1 Buy milk\n", "")


def test_untag_command(run):
    run("add", "Buy milk", "--tag", "home", "--tag", "errands", "--tag", "shop")
    assert run("untag", "1", "home", "shop") == (0, "Untagged task 1: Buy milk\n", "")
    assert run("list") == (0, "[ ] 1 Buy milk #errands\n", "")


def test_untag_a_missing_tag_is_not_an_error(run):
    run("add", "Buy milk", "--tag", "home")
    assert run("untag", "1", "work") == (0, "Untagged task 1: Buy milk\n", "")
    assert run("list") == (0, "[ ] 1 Buy milk #home\n", "")


def test_untag_unknown_id_is_an_error(run):
    assert run("untag", "4", "home") == (1, "", "error: no task with id 4\n")


def _tagged(run):
    run("add", "Buy milk", "--tag", "home")
    run("add", "Pay rent", "--priority", "high", "--tag", "bills")
    run("add", "Clean house", "--tag", "home")
    run("add", "Fix sink", "--priority", "low", "--tag", "home", "--tag", "diy")
    run("done", "3")


def test_list_tag_filters(run):
    _tagged(run)
    assert run("list", "--tag", "home") == (
        0,
        "[ ] 1 Buy milk #home\n[ ] 4 Fix sink (low) #home #diy\n",
        "",
    )
    assert run("list", "--tag", "home", "--all") == (
        0,
        "[ ] 1 Buy milk #home\n[x] 3 Clean house #home\n[ ] 4 Fix sink (low) #home #diy\n",
        "",
    )
    assert run("list", "--tag", "bills") == (0, "[ ] 2 Pay rent (high) #bills\n", "")


# Editing


def test_store_edit_title_and_priority(todo):
    store = TaskStore(todo)
    store.add("Buy milk")
    task = store.edit(1, title="Buy oat milk")
    assert (task.id, task.title, task.priority) == (1, "Buy oat milk", "normal")
    task = store.edit(1, priority="high")
    assert (task.title, task.priority) == ("Buy oat milk", "high")
    task = store.edit(1, title="Buy bread", priority="low")
    assert (task.title, task.priority) == ("Buy bread", "low")
    assert store.get(1).title == "Buy bread"


def test_store_edit_validates(todo):
    store = TaskStore(todo)
    store.add("Buy milk")
    with pytest.raises(ValueError, match="title must not be empty"):
        store.edit(1, title="   ")
    with pytest.raises(ValueError, match="unknown priority: urgent"):
        store.edit(1, priority="urgent")
    with pytest.raises(TaskNotFound, match="no task with id 5"):
        store.edit(5, title="x")


def test_cli_edit(run):
    run("add", "Buy milk")
    run("add", "Pay rent")
    assert run("edit", "1", "--title", "Buy oat milk") == (0, "Edited task 1: Buy oat milk\n", "")
    assert run("edit", "2", "--priority", "high") == (0, "Edited task 2: Pay rent\n", "")
    assert run("edit", "1", "--title", "Buy bread", "--priority", "low") == (
        0,
        "Edited task 1: Buy bread\n",
        "",
    )
    assert run("list") == (0, "[ ] 1 Buy bread (low)\n[ ] 2 Pay rent (high)\n", "")


def test_cli_edit_errors(run):
    run("add", "Buy milk")
    assert run("edit", "1") == (1, "", "error: nothing to edit\n")
    assert run("edit", "7", "--title", "x") == (1, "", "error: no task with id 7\n")
    assert run("edit", "1", "--title", "  ") == (1, "", "error: title must not be empty\n")
    assert run("list") == (0, "[ ] 1 Buy milk\n", "")


def test_cli_edit_keeps_tags(run):
    run("add", "Buy milk", "--tag", "home")
    run("edit", "1", "--priority", "high")
    assert run("list") == (0, "[ ] 1 Buy milk (high) #home\n", "")


# Sorting


def _mixed(run):
    run("add", "A low", "--priority", "low")
    run("add", "B normal")
    run("add", "C high", "--priority", "high")
    run("add", "D low", "--priority", "low")
    run("add", "E high", "--priority", "high")
    run("add", "F normal")


def test_sort_priority(run):
    _mixed(run)
    assert run("list", "--sort", "priority") == (
        0,
        "[ ] 3 C high (high)\n[ ] 5 E high (high)\n[ ] 2 B normal\n[ ] 6 F normal\n"
        "[ ] 1 A low (low)\n[ ] 4 D low (low)\n",
        "",
    )


def test_sort_id_is_the_default(run):
    _mixed(run)
    default = run("list")
    assert default[1].startswith("[ ] 1 A low (low)\n[ ] 2 B normal\n")
    assert run("list", "--sort", "id") == default


# Search


def test_store_search(todo):
    store = TaskStore(todo)
    store.add("Buy MILK")
    store.add("Pay rent")
    store.add("Milkshake")
    store.complete(3)
    assert [t.id for t in store.search("milk")] == [1, 3]
    assert [t.id for t in store.search("RENT")] == [2]
    assert store.search("bread") == []


def test_cli_search(run):
    run("add", "Buy MILK", "--tag", "home")
    run("add", "Pay rent", "--priority", "high")
    run("add", "Milkshake")
    run("done", "3")
    assert run("search", "milk") == (0, "[ ] 1 Buy MILK #home\n[x] 3 Milkshake\n", "")
    assert run("search", "bread") == (0, "No matches.\n", "")


# Stats


def test_stats(run):
    _mixed(run)
    run("add", "G high", "--priority", "high")
    run("done", "3")
    run("done", "1")
    assert run("stats") == (
        0,
        "Total: 7\nDone: 2\nPending: 5\nHigh priority pending: 2\n",
        "",
    )


def test_stats_on_an_empty_list(run):
    assert run("stats") == (0, "Total: 0\nDone: 0\nPending: 0\nHigh priority pending: 0\n", "")


# Export


def _export_data(run):
    run("add", "Buy milk", "--priority", "low", "--tag", "home", "--tag", "errands")
    run("add", "Pay rent", "--priority", "high", "--tag", "bills")
    run("add", 'Milk, eggs and "bread"')
    run("done", "2")


def test_export_csv(run):
    _export_data(run)
    code, out, err = run("export", "--format", "csv")
    assert (code, err) == (0, "")
    assert out == (
        "id,title,priority,done,tags\n"
        "1,Buy milk,low,no,home;errands\n"
        "2,Pay rent,high,yes,bills\n"
        '3,"Milk, eggs and ""bread""",normal,no,\n'
    )
    rows = list(csv.reader(io.StringIO(out)))
    assert rows[3] == ["3", 'Milk, eggs and "bread"', "normal", "no", ""]


def test_export_markdown(run):
    _export_data(run)
    assert run("export", "--format", "markdown") == (
        0,
        "# Tasks\n\n"
        "- [ ] Buy milk (low) #home #errands\n"
        "- [x] Pay rent (high) #bills\n"
        '- [ ] Milk, eggs and "bread"\n',
        "",
    )


@pytest.mark.parametrize("args", [("export",), ("export", "--format", "json")])
def test_export_format_usage_errors(todo, args):
    proc = _module(todo, *args)
    assert proc.returncode == 2
    assert proc.stdout == ""


# Existing behaviour


def test_existing_output_is_unchanged(run):
    assert run("add", "Buy milk") == (0, "Added task 1: Buy milk\n", "")
    run("add", "Pay rent", "--priority", "high")
    assert run("done", "1") == (0, "Completed task 1: Buy milk\n", "")
    assert run("list") == (0, "[ ] 2 Pay rent (high)\n", "")
    assert run("list", "--all") == (0, "[x] 1 Buy milk\n[ ] 2 Pay rent (high)\n", "")
    assert run("remove", "2") == (0, "Removed task 2: Pay rent\n", "")
    assert run("done", "7") == (1, "", "error: no task with id 7\n")
