"""The task record and its validation."""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from datetime import date
from typing import Any

PRIORITIES = ("low", "normal", "high")
_DATE_FORM = re.compile(r"\d{4}-\d{2}-\d{2}")


@dataclass
class Task:
    """One to-do item. The title is stripped; an empty title is an error.

    `due` is an optional `YYYY-MM-DD` date string.
    """

    id: int
    title: str
    priority: str = "normal"
    done: bool = False
    due: str | None = None

    def __post_init__(self) -> None:
        self.title = validate_title(self.title)
        self.priority = validate_priority(self.priority)
        if self.due is not None:
            parse_date(self.due)

    def to_dict(self) -> dict[str, Any]:
        """Return the task as a JSON-ready dict."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Task:
        """Build a task from a dict read from the task file."""
        return cls(
            id=int(data["id"]),
            title=data["title"],
            priority=data.get("priority", "normal"),
            done=bool(data.get("done", False)),
            due=data.get("due"),
        )


def validate_title(title: str) -> str:
    """Return the stripped title, or raise ValueError if nothing is left."""
    cleaned = title.strip()
    if not cleaned:
        raise ValueError("title must not be empty")
    return cleaned


def validate_priority(priority: str) -> str:
    """Return the priority if it is known, else raise ValueError."""
    if priority not in PRIORITIES:
        raise ValueError(f"unknown priority: {priority}")
    return priority


def parse_date(value: str) -> date:
    """Return the date for a `YYYY-MM-DD` string, else raise ValueError."""
    if isinstance(value, str) and _DATE_FORM.fullmatch(value):
        try:
            return date.fromisoformat(value)
        except ValueError:
            pass
    raise ValueError(f"invalid due date: {value}")
