"""Held-out checks for the fast request: optional due dates and the overdue list."""

import json
from datetime import date

import pytest

from tinytodo.cli import main
from tinytodo.model import Task
from tinytodo.store import TaskStore

TODAY = date(2026, 10, 5)
BAD_DATES = ["2026-13-01", "next week", "2026-02-30"]


@pytest.fixture
def todo(tmp_path, monkeypatch):
    monkeypatch.delenv("TINYTODO_FILE", raising=False)
    return tmp_path / "todo.json"


@pytest.fixture
def run(todo, capsys):
    def _run(*args):
        code = main(["--file", str(todo), *args])
        out, err = capsys.readouterr()
        return code, out, err

    return _run


# The model


def test_due_defaults_to_none():
    assert Task(id=1, title="Buy milk").due is None


def test_due_is_kept():
    assert Task(id=1, title="Buy milk", due="2026-10-01").due == "2026-10-01"


@pytest.mark.parametrize("value", BAD_DATES)
def test_bad_due_is_rejected(value):
    with pytest.raises(ValueError) as exc:
        Task(id=1, title="Buy milk", due=value)
    assert str(exc.value) == f"invalid due date: {value}"


def test_due_round_trips_through_a_dict():
    task = Task(id=2, title="Pay rent", priority="high", due="2026-10-01")
    assert task.to_dict()["due"] == "2026-10-01"
    assert Task.from_dict(task.to_dict()) == task
    assert Task(id=3, title="Call mom").to_dict()["due"] is None


def test_from_dict_without_due_has_no_due():
    assert Task.from_dict({"id": 2, "title": "Call mom"}).due is None


# The store


def test_add_takes_a_due_date(todo):
    store = TaskStore(todo)
    task = store.add("Pay rent", priority="high", due="2026-10-01")
    assert (task.priority, task.due) == ("high", "2026-10-01")
    assert store.add("Buy milk").due is None


def test_add_with_a_bad_due_adds_nothing(todo):
    store = TaskStore(todo)
    with pytest.raises(ValueError, match="invalid due date: 2026-13-01"):
        store.add("Pay rent", due="2026-13-01")
    assert store.list(include_done=True) == []


def test_due_is_saved_under_due_key(todo):
    store = TaskStore(todo)
    store.add("Buy milk")
    store.add("Pay rent", due="2026-10-01")
    store.save()
    tasks = json.loads(todo.read_text(encoding="utf-8"))["tasks"]
    assert [t["due"] for t in tasks] == [None, "2026-10-01"]
    reloaded = TaskStore(todo)
    assert [t.due for t in reloaded.list()] == [None, "2026-10-01"]


def test_old_file_without_due_still_loads(todo, run):
    todo.write_text(
        json.dumps(
            {
                "version": 1,
                "next_id": 3,
                "tasks": [
                    {"id": 1, "title": "Buy milk", "priority": "normal", "done": False},
                    {"id": 2, "title": "Pay rent", "priority": "high", "done": True},
                ],
            }
        ),
        encoding="utf-8",
    )
    store = TaskStore(todo)
    assert [t.due for t in store.list(include_done=True)] == [None, None]
    assert store.overdue(TODAY) == []
    assert run("list", "--all") == (0, "[ ] 1 Buy milk\n[x] 2 Pay rent (high)\n", "")


def _overdue_store(todo):
    store = TaskStore(todo)
    store.add("No date")  # 1
    store.add("Late b", due="2026-10-01")  # 2
    store.add("Due today", due="2026-10-05")  # 3
    store.add("Later", due="2026-10-06")  # 4
    store.add("Late a", due="2026-09-30")  # 5
    store.add("Done late", due="2026-09-01")  # 6
    store.add("Late c", due="2026-10-01")  # 7
    store.complete(6)
    return store


def test_overdue_sorted_by_due_then_id(todo):
    store = _overdue_store(todo)
    assert [t.id for t in store.overdue(TODAY)] == [5, 2, 7]


def test_overdue_depends_on_today(todo):
    store = _overdue_store(todo)
    assert [t.id for t in store.overdue(date(2026, 10, 6))] == [5, 2, 7, 3]
    assert store.overdue(date(2026, 9, 30)) == []


def test_overdue_on_empty_store(todo):
    assert TaskStore(todo).overdue(TODAY) == []


# The command line


def test_add_due_then_list(run):
    assert run("add", "Buy milk") == (0, "Added task 1: Buy milk\n", "")
    assert run("add", "Pay rent", "--priority", "high", "--due", "2026-10-01")[0] == 0
    assert run("add", "Water plants", "--due", "2026-11-15")[0] == 0
    code, out, err = run("list")
    assert (code, err) == (0, "")
    assert out == (
        "[ ] 1 Buy milk\n"
        "[ ] 2 Pay rent (high) due 2026-10-01\n"
        "[ ] 3 Water plants due 2026-11-15\n"
    )


def test_done_task_shows_due_with_all(run):
    run("add", "Buy milk", "--priority", "low", "--due", "2026-10-01")
    run("done", "1")
    assert run("list", "--all") == (0, "[x] 1 Buy milk (low) due 2026-10-01\n", "")


@pytest.mark.parametrize("value", ["2026-13-01", "next week"])
def test_cli_bad_due_is_an_error_and_adds_nothing(run, todo, value):
    run("add", "Buy milk")
    assert run("add", "Pay rent", "--due", value) == (1, "", f"error: invalid due date: {value}\n")
    assert run("list", "--all") == (0, "[ ] 1 Buy milk\n", "")
    assert run("add", "Call mom")[1] == "Added task 2: Call mom\n"


def test_cli_bad_due_on_empty_file_writes_nothing(run, todo):
    assert run("add", "Pay rent", "--due", "2026-02-30")[0] == 1
    assert TaskStore(todo).list(include_done=True) == []


def _overdue_cli(run):
    run("add", "No date")
    run("add", "Late b", "--due", "2026-10-01")
    run("add", "Due today", "--due", "2026-10-05")
    run("add", "Later", "--priority", "high", "--due", "2026-10-06")
    run("add", "Late a", "--priority", "high", "--due", "2026-09-30")
    run("add", "Done late", "--due", "2026-09-01")
    run("add", "Late c", "--due", "2026-10-01")
    run("done", "6")


def test_list_overdue_with_today(run):
    _overdue_cli(run)
    assert run("list", "--overdue", "--today", "2026-10-05") == (
        0,
        "[ ] 5 Late a (high) due 2026-09-30\n[ ] 2 Late b due 2026-10-01\n[ ] 7 Late c due 2026-10-01\n",
        "",
    )
    code, out, _ = run("list", "--overdue", "--today", "2026-10-07")
    assert code == 0
    assert out.splitlines()[-2:] == [
        "[ ] 3 Due today due 2026-10-05",
        "[ ] 4 Later (high) due 2026-10-06",
    ]


def test_list_overdue_defaults_to_the_real_today(run):
    run("add", "Long ago", "--due", "2000-01-01")
    run("add", "Far ahead", "--due", "9999-12-31")
    run("add", "No date")
    assert run("list", "--overdue") == (0, "[ ] 1 Long ago due 2000-01-01\n", "")


@pytest.mark.parametrize("value", ["2026-13-01", "next week"])
def test_list_overdue_bad_today_is_an_error(run, value):
    run("add", "Late", "--due", "2000-01-01")
    code, out, err = run("list", "--overdue", "--today", value)
    assert (code, out) == (1, "")
    assert err.startswith("error: ") and value in err and err.endswith("\n")


def test_list_without_overdue_is_unchanged(run):
    _overdue_cli(run)
    assert run("list") == (
        0,
        "[ ] 1 No date\n"
        "[ ] 2 Late b due 2026-10-01\n"
        "[ ] 3 Due today due 2026-10-05\n"
        "[ ] 4 Later (high) due 2026-10-06\n"
        "[ ] 5 Late a (high) due 2026-09-30\n"
        "[ ] 7 Late c due 2026-10-01\n",
        "",
    )
