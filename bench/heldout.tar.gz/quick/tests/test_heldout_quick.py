"""Held-out checks for the quick request: `list` prints `No tasks.` when nothing is shown."""

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

import tinytodo
from tinytodo.cli import main

EMPTY = "No tasks.\n"


@pytest.fixture
def todo(tmp_path, monkeypatch):
    monkeypatch.delenv("TINYTODO_FILE", raising=False)
    return tmp_path / "todo.json"


@pytest.fixture
def run(todo, capsys):
    def _run(*args):
        code = main(["--file", str(todo), *args])
        out, err = capsys.readouterr()
        return code, out, err

    return _run


@pytest.mark.parametrize("flags", [(), ("--all",)])
def test_missing_file_prints_message(run, todo, flags):
    assert run("list", *flags) == (0, EMPTY, "")
    assert not todo.exists()


@pytest.mark.parametrize("flags", [(), ("--all",)])
def test_file_with_no_tasks_prints_message(run, todo, flags):
    todo.write_text(json.dumps({"version": 1, "next_id": 1, "tasks": []}), encoding="utf-8")
    assert run("list", *flags) == (0, EMPTY, "")


def test_message_after_last_task_is_removed(run):
    run("add", "Buy milk")
    run("remove", "1")
    assert run("list") == (0, EMPTY, "")
    assert run("list", "--all") == (0, EMPTY, "")


def test_all_done_prints_message_without_all(run):
    run("add", "Buy milk")
    run("add", "Pay rent")
    run("done", "1")
    run("done", "2")
    assert run("list") == (0, EMPTY, "")
    assert run("list", "--all") == (0, "[x] 1 Buy milk\n[x] 2 Pay rent\n", "")


def test_output_with_tasks_is_unchanged(run):
    run("add", "Buy milk")
    run("add", "Pay rent", "--priority", "high")
    run("add", "Water plants", "--priority", "low")
    run("done", "2")
    assert run("list") == (0, "[ ] 1 Buy milk\n[ ] 3 Water plants (low)\n", "")
    assert run("list", "--all") == (
        0,
        "[ ] 1 Buy milk\n[x] 2 Pay rent (high)\n[ ] 3 Water plants (low)\n",
        "",
    )


def test_env_file_with_no_tasks_prints_message(tmp_path, capsys, monkeypatch):
    monkeypatch.setenv("TINYTODO_FILE", str(tmp_path / "other.json"))
    assert main(["list"]) == 0
    assert capsys.readouterr() == (EMPTY, "")


def test_module_command_prints_message(tmp_path):
    env = {k: v for k, v in os.environ.items() if k != "TINYTODO_FILE"}
    env["PYTHONPATH"] = str(Path(tinytodo.__file__).resolve().parent.parent)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    proc = subprocess.run(
        [sys.executable, "-m", "tinytodo", "list"],
        cwd=tmp_path,
        env=env,
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert (proc.returncode, proc.stdout, proc.stderr) == (0, EMPTY, "")
